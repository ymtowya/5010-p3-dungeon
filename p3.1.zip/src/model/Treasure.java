package model;

/**
 * Enumeration of the treasures.
 *
 */
public enum Treasure {
  DIAMONDS,
  RUBIES,
  SAPPHIRES;
}
