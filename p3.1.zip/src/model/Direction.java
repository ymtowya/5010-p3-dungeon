package model;

/**
 * Enumeration of the directions.
 *
 */
public enum Direction {
  NORTH,
  WEST,
  EAST,
  SOUTH;
}
